import GamingPortfolio from "@/components/gaming-portfolio"

export default function Home() {
  return (
    <main>
      <GamingPortfolio />
    </main>
  )
}
